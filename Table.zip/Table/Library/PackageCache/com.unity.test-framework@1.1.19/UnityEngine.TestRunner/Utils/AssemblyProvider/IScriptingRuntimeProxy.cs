namespace UnityEngine.TestTools.Utils
{
    internal interface IScriptingRuntimeProxy
    {
        string[] GetAllUserAssemblies();
    }
}
